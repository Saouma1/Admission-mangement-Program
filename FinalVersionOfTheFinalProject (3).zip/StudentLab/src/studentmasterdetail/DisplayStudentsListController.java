/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmasterdetail;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;


public class DisplayStudentsListController implements Initializable {

    
    @FXML
    private TextArea display;
    private static final String FILE_NAME = "studentList.txt";
   /**
This method would scan the data inside the file, read it, and print it in a textArea in a new window.
 */
    @Override
    public void initialize(URL url, ResourceBundle rb) { // This code runs when the button display is pressed and it shows 
        ArrayList<student> student1 = new ArrayList<>();
        student student;
        String line;
        String[] tokens;
        String firstName;
        String lastName;
        String ID;
        String major;
        String minor;
        String finalStep="";
        
        try (Scanner fileInput = new Scanner(new File(FILE_NAME)))
        {

            while(fileInput.hasNext())
            {
                line = fileInput.nextLine();
                tokens = line.split(",");
                student = new student();

                firstName = tokens[0];
                lastName =tokens[1];
                ID = tokens[2];
                major = tokens[3];
                minor = tokens[4];
                
                student.setFirstName(firstName);
                student.setLastName(lastName);
                student.setID(ID);
                student.setMajor(major);
                student.setMinor(minor);

                student1.add(student);
                display.getText();   
                finalStep += student.fullToString()+"\n";
                
                
            }
            display.setText(finalStep);
            
            System.out.println("Your Address Book has been loaded into the system.");
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("Error, " + FILE_NAME + " could not be found.");
            System.out.println("More details: " + exception.getMessage());
        }
    }
    
    
    
}
