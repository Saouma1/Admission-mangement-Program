
package studentmasterdetail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
*This method would scan the data inside the file, read it, and print it in a textArea in a new window.
 */
public class TeacherWindowController extends student implements Initializable {

     @FXML
    private TextField IDField;

    @FXML
    private Button deleteButton;

    @FXML
    private Button displayButton;

    @FXML
    private TextField firstNameTextField;

    @FXML
    private TextField lastNameTextField;

    @FXML
    private ListView listViewTeacher;

    @FXML
    private Button newButton;

    @FXML
    private TextField studentsTextField;

    @FXML
    private TextField subjectTextField;

    @FXML
    private Button updatebutton;
    
    @FXML
    private Button saveButton;

    
    
    
    private ObservableList<teacher> teacherList = FXCollections.observableArrayList(teacher.extractor);
    private static final String FILE_NAME = "teacherList.txt";
    private ChangeListener<teacher> teacherChangeListener;
    
    private teacher t;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        teacherList.add(new teacher("Kris" , "Glesner", "B00848586", "CIS",100));
        teacherList.add(new teacher("Clemente" , "Infante", "B1235649", "Business",25));
        teacherList.add(new teacher("Tarek" , "Saouma", "B06488586", "Information Systems",3));
        teacherList.add(new teacher("Adolfo" , "Rivas", "B00764586", "Business",6));      
        listViewTeacher.setItems(teacherList);
        
           listViewTeacher.getSelectionModel().selectedItemProperty().addListener(
            teacherChangeListener = (observable, oldValue, newValue) -> {
                // Set the selected Student.
                t = newValue;
                    
                    if(newValue != null){
                    firstNameTextField.setText(t.getFirstName());
                    lastNameTextField.setText(t.getLastName());
                    IDField.setText(t.getID());
                    subjectTextField.setText(t.getSubject());
                    studentsTextField.setText(""+t.getNumberOfStudents());
                }
                else
                {
                    firstNameTextField.setText("");
                    lastNameTextField.setText("");
                    IDField.setText("");
                    subjectTextField.setText("");
                    studentsTextField.setText(""+0);
                }

            });
        newButton.disableProperty().bind(firstNameTextField.textProperty().isEmpty());      
        updatebutton.disableProperty().bind(listViewTeacher.getSelectionModel().selectedItemProperty().isNull());
        deleteButton.disableProperty().bind(listViewTeacher.getSelectionModel().selectedItemProperty().isNull());
        displayButton.disableProperty().bind(listViewTeacher.getSelectionModel().selectedItemProperty().isNull());
        saveButton.disableProperty().bind(listViewTeacher.getSelectionModel().selectedItemProperty().isNull());
                
                    
        
        // TODO
    }    
       @FXML
    void deleteButton(ActionEvent event) {
        teacherList.remove(t);
    }
/**
This method contain the dispaly button, but this one do not open a new window but it print in the console.
 */
      @FXML
    void displayButton(ActionEvent event) {
        
        ArrayList<teacher> teacher1 = new ArrayList<>();
        teacher teacher;
        String line;
        String[] tokens;
        String firstName;
        String lastName;
        String ID;
        String subject;
        int numberOfStudents;
        String finalStep="";
        
        try (Scanner fileInput = new Scanner(new File(FILE_NAME)))
        {

            while(fileInput.hasNext())
            {
                line = fileInput.nextLine();
                tokens = line.split(",");
                teacher = new teacher();

                firstName = tokens[0];
                lastName =tokens[1];
                ID = tokens[2];
                subject = tokens[3];
                numberOfStudents = Integer.parseInt(tokens[4]);
                
                teacher.setFirstName(firstName);
                teacher.setLastName(lastName);
                teacher.setID(ID);
                teacher.setSubject(subject);
                teacher.setNumberOfStudents(numberOfStudents);

                teacher1.add(teacher); 
                finalStep += teacher.fullToString()+"\n";
                
                
            }
            System.out.println();
            System.out.println(finalStep);
            
            System.out.println("Your Address Book has been loaded into the system.");
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("Error, " + FILE_NAME + " could not be found.");
            System.out.println("More details: " + exception.getMessage());
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("More details: " + e.getMessage());
        }
    }
    /**
This method contains the save button 
 */
     @FXML
    void saveButton(ActionEvent event) {
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String subject = subjectTextField.getText();
        int numberOfStudents ;
        try {
          numberOfStudents = Integer.parseInt(studentsTextField.getText());
        }
       catch(NumberFormatException e){
           numberOfStudents = 0;
       }
        ArrayList<teacher> teacherNew = new ArrayList();
        teacher teacherN = new teacher(firstName, lastName, ID, subject, numberOfStudents);
          teacherNew.add(teacherN);
        System.out.println(teacherN.fullToString());
     
        FileWriter fw;
        BufferedWriter bw; 
        PrintWriter pw;
    try { 
    fw = new FileWriter("teacherList.txt", true);
    bw = new BufferedWriter(fw); 
    pw = new PrintWriter(bw);
    
    pw.println(teacherN.fullToString());  
    System.out.println("Data Successfully appended into file"); 
    pw.flush();
        } catch (IOException io) {
            
        }
    }
/**
This method contains the new button
 */
     @FXML
    void newButton(ActionEvent event) {
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String subject = subjectTextField.getText();
        int numberOfStudents ;
        try {
          numberOfStudents = Integer.parseInt(studentsTextField.getText());
        }
       catch(NumberFormatException e){
           numberOfStudents = 0;
       }
        teacher added = new teacher(firstName, lastName,ID,subject,numberOfStudents);
        teacherList.add(added);
        listViewTeacher.getSelectionModel().select(added);
    }

    /**
This method contains the update button
 */
    @FXML
    void updatebutton(ActionEvent event) {
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String subject = subjectTextField.getText();
        int numberOfStudents ;
        try {
          numberOfStudents = Integer.parseInt(studentsTextField.getText());
        }
       catch(NumberFormatException e){
           numberOfStudents = 0;
       }
        t.setFirstName(firstName);
        t.setLastName(lastName);
        t.setID(ID);
        t.setSubject(subject);
        t.setNumberOfStudents(numberOfStudents);
         listViewTeacher.getSelectionModel().selectedItemProperty().addListener(teacherChangeListener);
    }

}
