/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmasterdetail;

import java.io.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


/**
 *it contains all the functionality, buttons, textAreas and list view in the student window. 
 */
public class StudentWindowController implements Initializable {

    @FXML
    private TextField IDField;

    @FXML
    private Button deleteButton;

    @FXML
    private Button displayButton;

    @FXML
    private TextField firstNameTextField;

    @FXML
    private TextField lastNameTextField;

    @FXML
    private TextField majorTextField;

    @FXML
    private TextField minorField;

    @FXML
    private Button newButton;

    @FXML
    private Button updateButton;
    
    @FXML
    private ListView listViewStudents;
    
    @FXML
    private Button saveButton;
    
/**
 *The name of the file
 */
    private static final String FILE_NAME = "studentList.txt";
    
    private ObservableList<student> studentList = FXCollections.observableArrayList(student.extractor);
     private ChangeListener<student> studentChangeListener;
    private student s;
    @Override
    public void initialize(URL url, ResourceBundle rb) {       

               

        studentList.add(new student("Jad" , "Saouma", "B00848586", "Computer Science","Data Analytics"));
        studentList.add(new student("Clemente" , "Infante", "B1235649", "Business","None"));
        studentList.add(new student("Tarek" , "Saouma", "B06488586", "Information Systems","Management"));
        studentList.add(new student("Adolfo" , "Rivas", "B00764586", "Business","None"));      
        listViewStudents.setItems(studentList);
        
        listViewStudents.getSelectionModel().selectedItemProperty().addListener(
            studentChangeListener = (observable, oldValue, newValue) -> {
                // Set the selected Student.
                s = newValue;

                if(newValue != null){
                    firstNameTextField.setText(s.getFirstName());
                    lastNameTextField.setText(s.getLastName());
                    IDField.setText(s.getID());
                    majorTextField.setText(s.getMajor());
                    minorField.setText(s.getMinor());
                }
                else
                {
                    firstNameTextField.setText("");
                    lastNameTextField.setText("");
                    IDField.setText("");
                    majorTextField.setText("");
                    minorField.setText("");
                }
            });
        newButton.disableProperty().bind(firstNameTextField.textProperty().isEmpty());      
        updateButton.disableProperty().bind(listViewStudents.getSelectionModel().selectedItemProperty().isNull());
        deleteButton.disableProperty().bind(listViewStudents.getSelectionModel().selectedItemProperty().isNull());
        displayButton.disableProperty().bind(listViewStudents.getSelectionModel().selectedItemProperty().isNull());
        saveButton.disableProperty().bind(listViewStudents.getSelectionModel().selectedItemProperty().isNull());          
    }
   /**
 *THis is the new button 
 */
    @FXML
   private void newAction(ActionEvent event){
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String major = majorTextField.getText();
        String minor = minorField.getText();
        
        student added = new student(firstName, lastName,ID,major,minor);
        
        studentList.add(added);
         listViewStudents.getSelectionModel().select(added);
    }
   /**
 *THis is the delete button 
 */
    @FXML
    private void deleteButton(ActionEvent event) {
        studentList.remove(s);
    }
/**
 *THis is the display button 
 */
    @FXML
    void displayButton(ActionEvent event) {
       try{
             
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("displayStudentsList.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Display Window");
        stage.setScene(new Scene(root1));
        stage.show();
         } catch (IOException e){
             System.out.println("Sorry we can't load this screen");
         }
     
    
    }
    /**
 *THis is the update button 
 */
    @FXML
    void updateButton(ActionEvent event) {
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String major = majorTextField.getText();
        String minor = minorField.getText();
        
        s.setFirstName(firstName);
        s.setLastName(lastName);
        s.setID(ID);
        s.setMajor(major);
        s.setMinor(minor);
        
         listViewStudents.getSelectionModel().selectedItemProperty().addListener(studentChangeListener);
    } 
     
    /**
     *
     * it contains the save button
     */
    @FXML
    private void saveButton (ActionEvent event){
        
        String firstName = firstNameTextField.getText();
        String lastName =lastNameTextField.getText();
        String ID = IDField.getText();
        String major = majorTextField.getText();
        String minor = minorField.getText();
        ArrayList<student> studentNew = new ArrayList();
        student studentN = new student(firstName, lastName, ID, major, minor);
          studentNew.add(studentN);
        System.out.println(studentN.fullToString());
     
        FileWriter fw;
        BufferedWriter bw; 
        PrintWriter pw;
    try { 
    fw = new FileWriter("studentList.txt", true);
    bw = new BufferedWriter(fw); 
    pw = new PrintWriter(bw);
    
    pw.println(studentN.fullToString());  
    System.out.println("Data Successfully appended into file"); 
    pw.flush();
        } catch (IOException io) {
            
        }
        
    }  
         
  }
    
    


