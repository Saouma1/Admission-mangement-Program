package studentmasterdetail;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.util.Callback;

// you cann see that this method extends student so I don't have to repeat the same attributes.
public class teacher extends student {
    // attributes
    private IntegerProperty numberOfStudents;
    private StringProperty subject;
    
    public teacher (){
        subject = new SimpleStringProperty(this,"subject","");
        numberOfStudents = new SimpleIntegerProperty(this,"numberOfStudents",0);
        super.firstName = new SimpleStringProperty(this,"firstName", "");
        super.lastName = new SimpleStringProperty(this,"lastName", "");
        super.ID = new SimpleStringProperty (this,"ID", "");
    }
    
    public teacher (String inFirstName,String inLastName,String inID,String inSubject, int inNumberOfStudents){
        subject = new SimpleStringProperty(this,"subject",inSubject);
        numberOfStudents = new SimpleIntegerProperty(this,"numberOfStudents",inNumberOfStudents);
        super.firstName = new SimpleStringProperty(this,"firstName", inFirstName);
        super.lastName = new SimpleStringProperty(this,"lastName", inLastName);
        super.ID = new SimpleStringProperty (this,"ID", inID); 
    }
    
    public void setSubject(String inSubject){
        subject.set(inSubject);
    }
    public String getSubject(){
        return subject.get();
    }
    public StringProperty subjectProperty(){
        return subject;
    }
    public void setNumberOfStudents(int inNumberOfStudents){
        numberOfStudents.set(inNumberOfStudents);
    }
    public int getNumberOfStudents(){
        return numberOfStudents.get();
    }
    public IntegerProperty numberOfStudentsProperty(){
        return numberOfStudents;
    }
    
    @Override
    public String toString(){
         return firstName .getValue()+" "+ lastName.getValue();
    }
    @Override
     public String fullToString(){
         return firstName .getValue()+","+ lastName.getValue()+","+ ID.getValue()+","+ subject.getValue()+","+ numberOfStudents.getValue();
    }
    public static Callback<teacher, javafx.beans.Observable[]> extractor = o -> new javafx.beans.Observable[]
        {o.firstNameProperty(), o.lastNameProperty()
    };
}