package studentmasterdetail;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable
{
    // Controls from FXML GUI Interface.
/**
This method has a button that opens the studentWindow window
 */
    @FXML
     void handleButtonActionStudent(ActionEvent event) {
        try{
             
             FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("studentWindow.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Student Window");
        stage.setScene(new Scene(root1));
        stage.show();
         } catch (IOException e){
             System.out.println("Sorry we can't load this screen");
         }
        
    /**
This method has a button that opens the teacherWindow window
 */
    }
     @FXML
     void handleButtonActionTeacher(ActionEvent event) {
        try{
             
             FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("teacherWindow.fxml"));
        Parent root2 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Teacher Window");
        stage.setScene(new Scene(root2));
        stage.show();
         } catch (IOException e){
             System.out.println("Sorry we can't load this screen");
         }
        
    
    }
    
    // Called when the program first starts.
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        // TODO
    } 
}
