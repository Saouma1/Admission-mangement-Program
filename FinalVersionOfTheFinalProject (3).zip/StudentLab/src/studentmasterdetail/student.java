
package studentmasterdetail;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.util.Callback;


public class student {
    // attributes
    protected StringProperty firstName;
    protected StringProperty lastName;
    protected StringProperty ID;
    private StringProperty major;
    private StringProperty minor;
    
    public student (){
        firstName = new SimpleStringProperty(this,"firstName","");
        lastName = new SimpleStringProperty(this,"lastName","");
        ID = new SimpleStringProperty(this,"ID","");
        major = new SimpleStringProperty(this,"major","");
        minor = new SimpleStringProperty(this,"minor","");   
    }
    
    public student(String inFirstName,String inLastName,String inID,String inMajor,String inMinor){
        firstName = new SimpleStringProperty(this,"firstName",inFirstName);
        lastName = new SimpleStringProperty(this,"lastName",inLastName);
        ID = new SimpleStringProperty(this,"ID",inID);
        major = new SimpleStringProperty(this,"major",inMajor);
        minor = new SimpleStringProperty(this,"minor",inMinor);
    }
    /*
    *set first name method
    */
    public void setFirstName(String inFirstName){
        firstName.set(inFirstName);
    }
     /*
    *get first name method
    */
    public String getFirstName(){
        return firstName.get();
    }
     /*
    *return the String Property of the firstName
    */
    public StringProperty firstNameProperty(){
        return firstName;
    }
    
     /*
    *set last name method
    */
    public void setLastName(String inLastName){
        lastName.set(inLastName);
    }
     /*
    *get last name method
    */
    public String getLastName(){
        return lastName.get();
    }
     /*
    *return the StringPropery of the lastName
    */
    public StringProperty lastNameProperty(){
        return lastName;
    }
    
     /*
    *set ID method
    */
    public void setID(String inID){
        ID.set(inID);
    }
    /*
    *get ID method
    */
    public String getID(){
        return ID.get();
    }
    /*
    *return the StringProperty of the ID
    */
    public StringProperty IDProperty(){
        return ID;
    }
    
    /*
    *set Major method
    */
    public void setMajor(String inMajor){
        major.set(inMajor);
    }
    /*
    *get major method
    */
    public String getMajor(){
        return major.get();
    }
    /*
    *return the StringProperty of the major
    */
    public StringProperty majorProperty(){
        return major;
    }
     /*
    *set minor method
    */
    public void setMinor (String inMinor){
        minor.set(inMinor);
    }
    /*
    *get minor method
    */
    public String getMinor(){
        return minor.get();
    }
    /*
    *return the StringProperty of the minor
    */
    public StringProperty minorProperty(){
        return minor;
    }
    
    /*
    *it returns the first and last name that are displaying in the list view.
    */
    @Override
    public String toString()
    {
        return firstName .getValue()+" "+ lastName.getValue();
    }
    /*
    *it returns all the attributes that are displaying in the file.
    */
    public String fullToString()
    {
        return firstName .getValue()+","+ lastName.getValue()+","+ID .getValue()+","+ major.getValue()+","+minor .getValue();
    }
    /*
    *The equals method that checks if 2 objects are equal.
    */
    @Override
    public boolean equals(Object object)
    {
        boolean areEqual;
        
        if (this == object)
        {
            areEqual = true;
        }
        else if (object == null)
        {
            areEqual = false;
        }
        else if (getClass() != object.getClass())
        {
            areEqual = false;
        }
        else
        {
            student other = (student) object;
            
            if      (getFirstName().equals(other.getFirstName())
                    && getLastName().equals(other.getLastName())
                    && getID().equals(other.getID())
                    && getMajor().equals(other.getMajor())
                    && getMinor().equals(other.getMinor()))
            {
                areEqual = true;
            }
            else
            {
                areEqual = false;
            }
        }

        return areEqual;
    }
    public static Callback<student, javafx.beans.Observable[]> extractor = o -> new javafx.beans.Observable[]
        {o.firstNameProperty(), o.lastNameProperty()};
}
